"""Start a local-only static lab, with no external dependencies."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from functools import partial
import os
import webbrowser

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        # The browser lab can load the shared analyser but no parent directories.
        if path.split('?', 1)[0].startswith('/shared/'):
            return str(ROOT / 'shared' / Path(path.split('?', 1)[0]).name)
        return super().translate_path(path)

if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', 8765), partial(Handler, directory=str(ROOT / 'lab')))
    print('Лаборатория: http://127.0.0.1:8765/   Остановка: Ctrl+C', flush=True)
    webbrowser.open('http://127.0.0.1:8765/')
    server.serve_forever()
