document.getElementById('show').addEventListener('click',async()=>{
  try {const [tab]=await browser.tabs.query({active:true,currentWindow:true});await browser.tabs.sendMessage(tab.id,{type:'show-analysis'});window.close()}
  catch {document.getElementById('status').textContent='Страница недоступна для анализа. Откройте обычную веб-страницу и повторите.'}
});
