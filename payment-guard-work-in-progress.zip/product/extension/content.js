(() => {
  'use strict';
  // No input values are inspected or saved. Exception is bound to the exact origin.
  const origin = location.origin;
  let lastKey = '', timer;
  const cardPattern = /cc-number|card.?number|номер карты|номер банковской карты/i;
  const paymentPattern = /оплатить|оплата|перевести|перевод|pay now|checkout|purchase/i;
  function collect() {
    const fields = [...document.querySelectorAll('input')];
    const hasCard = fields.some(e => cardPattern.test([e.autocomplete,e.name,e.id,e.placeholder,e.getAttribute('aria-label')].join(' ')));
    const buttons = [...document.querySelectorAll('button,input[type=submit],[role=button],a[href]')];
    const hasPaymentButton = buttons.some(e => paymentPattern.test((e.innerText || e.value || e.getAttribute('aria-label') || '').slice(0,120)));
    return {text:(document.body?.innerText || '').slice(0,12000), hasCard, hasPaymentButton};
  }
  async function inspect(force = false) {
    if (!document.body) return;
    const obs = collect(), result = PaymentAnalyzer.analyze(obs);
    const warnings = result.reasons.filter(r => r.severity === 'warning');
    const storage = await browser.storage.local.get('ordinaryExceptions');
    const exceptions = storage.ordinaryExceptions || {};
    const shown = exceptions[origin] ? warnings : result.reasons;
    const key = shown.map(r=>r.code).join(',');
    if ((!key && !force) || (!force && key === lastKey)) return;
    lastKey = key;
    document.querySelector('#payment-study-notice')?.remove();
    if (!shown.length && !force) return;
    const host = document.createElement('div'); host.id='payment-study-notice';
    const shadow=host.attachShadow({mode:'closed'}), box=document.createElement('section');
    box.setAttribute('role','status');
    box.style.cssText='position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:380px;background:#fff;color:#18202a;padding:18px;border:2px solid #a96c08;border-radius:12px;box-shadow:0 4px 20px #0004;font:15px/1.45 system-ui';
    const title=document.createElement('strong'); title.textContent=warnings.length?'Найдены признаки для проверки':'Платёжный помощник'; box.append(title);
    const list=document.createElement('ul');
    shown.forEach(r=>{const li=document.createElement('li');li.textContent=r.message;list.append(li)});
    if (!shown.length) {const li=document.createElement('li');li.textContent='Доступные признаки не найдены. Безопасность не установлена.';list.append(li)}
    box.append(list);
    const note=document.createElement('p');note.textContent='Учебный прототип не блокирует ввод и не гарантирует безопасность. Встроенные формы и скрипты могут быть недоступны.';box.append(note);
    if (obs.hasCard || obs.hasPaymentButton) {
      const label=document.createElement('label'), check=document.createElement('input');
      check.type='checkbox';check.checked=!!exceptions[origin];label.append(check,document.createTextNode(' Не показывать обычное уведомление для этого сайта'));box.append(label);
      check.addEventListener('change',async()=>{const s=await browser.storage.local.get('ordinaryExceptions');const data=s.ordinaryExceptions||{};if(check.checked)data[origin]=true;else delete data[origin];await browser.storage.local.set({ordinaryExceptions:data});});
      const desc=document.createElement('p');desc.textContent='Предупреждения о найденных признаках угроз это не отключает.';box.append(desc);
    }
    const close=document.createElement('button');close.type='button';close.textContent='Понятно';close.onclick=()=>host.remove();box.append(close);
    shadow.append(box);document.documentElement.append(host);
  }
  browser.runtime.onMessage.addListener(message=>{if(message && message.type==='show-analysis'){inspect(true);return Promise.resolve({received:true})}});
  inspect();
  const observer=new MutationObserver(records=>{if(records.every(r=>r.target.closest?.('#payment-study-notice')))return;clearTimeout(timer);timer=setTimeout(()=>inspect(),500)});
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
})();
