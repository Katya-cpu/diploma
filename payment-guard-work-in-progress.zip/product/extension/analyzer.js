(function (root) {
  'use strict';
  // The analyser accepts observations, not page contents or entered secrets.
  function analyze(o) {
    const reasons = [];
    const text = String(o.text || '').slice(0, 12000).toLowerCase();
    const hasCard = !!o.hasCard;
    const manual = /(переведите|перевести|перевод|зайдите в.*банк)/i.test(text) && /(номер карты|карту получателя|карты получателя|по номеру карты)/i.test(text);
    const urgency = /(срочно|немедленно|только сегодня|иначе.*(отмен|заблок))/i.test(text);
    const contradictory = /(получить деньги|получите деньги|получение средств)/i.test(text) && /(оплатить|комисси|переведите)/i.test(text);
    if (hasCard) reasons.push({code:'card', severity:'notice', message:'Найдено поле для платёжной карты. Проверьте, кому и зачем вы передаёте данные.'});
    if (manual) reasons.push({code:'manual_transfer', severity:'warning', message:'Страница предлагает отдельный перевод по номеру карты. Уточните получателя и условия сделки.'});
    if (urgency && (hasCard || manual || o.hasPaymentButton)) reasons.push({code:'urgency', severity:'warning', message:'Есть призыв поторопиться рядом с платёжным действием.'});
    if (contradictory) reasons.push({code:'contradiction', severity:'warning', message:'Для получения денег страница одновременно просит оплату или перевод.'});
    if (o.hasPaymentButton) reasons.push({code:'payment_action', severity:'notice', message:'Найдено возможное платёжное действие: проверьте его назначение.'});
    const warnings = reasons.filter(r => r.severity === 'warning').length;
    return {status: warnings ? 'warning' : reasons.length ? 'notice' : 'unknown', reasons, limitations:['Проверены только доступные признаки страницы; безопасность не гарантируется.','Получатель и поведение недоступных скриптов не установлены.']};
  }
  root.PaymentAnalyzer = {analyze};
  if (typeof module !== 'undefined') module.exports = root.PaymentAnalyzer;
})(typeof globalThis !== 'undefined' ? globalThis : this);
