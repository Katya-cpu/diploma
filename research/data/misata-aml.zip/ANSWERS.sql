-- The questions on misata.studio/datasets/aml-transactions-ground-truth, each with the query that answers it.
-- Run in DuckDB from this folder: duckdb < ANSWERS.sql

create view accounts as select * from 'accounts.csv';
create view alerts as select * from 'alerts.csv';
create view cases as select * from 'cases.csv';
create view counterparties as select * from 'counterparties.csv';
create view customers as select * from 'customers.csv';
create view transactions as select * from 'transactions.csv';

-- 1. What precision and recall does a simple amount-threshold rule reach against the typology labels?
-- Flagging amounts of $10,000 or more: precision 16.1%, recall 6.1%.
with thresholds as (
  select 5000 as threshold union all select 9000 union all select 10000 union all select 50000
)
select t.threshold,
       sum(case when x.amount >= t.threshold then 1 else 0 end) as flagged,
       sum(case when x.amount >= t.threshold and x.is_suspicious then 1 else 0 end) as true_hits,
       round(100.0 * sum(case when x.amount >= t.threshold and x.is_suspicious then 1 else 0 end)
             / nullif(sum(case when x.amount >= t.threshold then 1 else 0 end), 0), 1) as precision_pct,
       round(100.0 * sum(case when x.amount >= t.threshold and x.is_suspicious then 1 else 0 end)
             / sum(case when x.is_suspicious then 1 else 0 end), 1) as recall_pct
from thresholds t
cross join transactions x
group by t.threshold
order by t.threshold;

-- 2. Which typology is hardest to catch with rules alone?
-- layering is caught least: 10 of 12 customers using it drew a true alert.
with launderers as (
  select distinct customer_id, typology
  from transactions
  where is_suspicious
),
alerted as (
  select distinct customer_id from alerts where is_true_positive
)
select l.typology,
       count(*) as customers,
       sum(case when a.customer_id is not null then 1 else 0 end) as alerted,
       round(100.0 * sum(case when a.customer_id is not null then 1 else 0 end) / count(*), 1) as detected_pct
from launderers l
left join alerted a on a.customer_id = l.customer_id
group by l.typology
order by detected_pct, customers desc;

-- 3. How many alerts does an investigator work for each true launderer found?
-- 84 alerts find 22 of the 24 customers in suspicious activity: 3.8 alerts for each one found.
select count(*) as alerts,
       sum(case when is_true_positive then 1 else 0 end) as true_alerts,
       count(distinct case when is_true_positive then customer_id end) as launderers_found,
       (select count(distinct customer_id) from transactions where is_suspicious) as customers_in_suspicious_activity,
       round(1.0 * count(*) / count(distinct case when is_true_positive then customer_id end), 1) as alerts_per_launderer_found
from alerts;

-- 4. Do structured cash deposits cluster in the days before a case opens?
-- Structured deposits by when they fell against their customer's case: 8-30 days before 25, 0-7 days before 25, after the case opened 10.
with d as (
  select extract(epoch from (c.opened_at - t.txn_at)) / 86400 as days_before
  from transactions t
  join cases c on c.customer_id = t.customer_id
  where t.typology = 'structuring'
)
select case when days_before < 0 then 'after the case opened'
            when days_before <= 7 then '0-7 days before'
            when days_before <= 30 then '8-30 days before'
            when days_before <= 90 then '31-90 days before'
            else 'over 90 days before' end as timing,
       count(*) as deposits
from d
group by 1
order by min(days_before) desc;
